
public class FactoriaMontana implements FactoriaCarrera{

	@Override
	public Carrera crearCarrera(int numCorredores) {
		return new CarreraMontana(numCorredores);
	}

}
