
public enum TC {
	MONTANA, CARRETERA
}
