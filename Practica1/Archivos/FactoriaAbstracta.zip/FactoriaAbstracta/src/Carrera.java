import java.util.ArrayList;


public abstract class Carrera extends Thread{
	
	protected ArrayList<Bicicleta> bicis = new ArrayList<>();
	
	
	public abstract void run();
}
