import java.util.Random;

public class CarreraMontana extends Carrera {
	
	public CarreraMontana(int numCorredores) {
		for(int i=0;i<numCorredores;i++) {
			bicis.add(new Bicicleta(TC.MONTANA));
		}
	}


	@Override
	public void run() {
		Random rnd = new Random();
		int eliminado = Math.abs(rnd.nextInt() % bicis.size());
		
		if(bicis.size() <= 5)
			bicis.remove(eliminado);
		else {
			int numeroEliminados = (bicis.size() * 20)/100;
			
			for(int i=0;i<numeroEliminados;i++) {
				bicis.remove(eliminado);
				eliminado = Math.abs(rnd.nextInt() % bicis.size());
			}
		}
		
	}
}
