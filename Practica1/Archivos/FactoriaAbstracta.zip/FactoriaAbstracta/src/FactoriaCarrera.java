

public interface FactoriaCarrera{
	public Carrera crearCarrera(int numCorredores);
}
