
public abstract class Visitante_Equipo {
	public abstract void visitarDisco(Disco d);
	public abstract void visitarBus(Bus b);
	public abstract void visitarTarjeta(Tarjeta t);
}
