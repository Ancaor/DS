
public enum Tipo_Cliente {
	VIP,
	MAYORISTA,
	SIN_DESCUENTO;
}
