
public class Disco extends Elemento_Equipo{

	public Disco(String nombre,double precio, double potencia) {
		super(nombre);
		this.precioNeto = precio;
		this.potencia = potencia;
	}
	
	@Override
	public void aceptar(Visitante_Equipo visitante) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double potencia() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double precioNeto() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double precioConDescuento() {
		// TODO Auto-generated method stub
		return 0;
	}

}
