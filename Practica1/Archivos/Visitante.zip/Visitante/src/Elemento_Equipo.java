
public abstract class Elemento_Equipo {
	protected String nombre;
	protected double potencia;
	protected double precioNeto;
	
	public Elemento_Equipo(String n) {
		nombre = n;
	}
	
	public String nombre() {
		return nombre;
	}
	
	public abstract void aceptar(Visitante_Equipo visitante);
	public abstract double potencia();
	public abstract double precioNeto();
	public abstract double precioConDescuento();
	
	
}
