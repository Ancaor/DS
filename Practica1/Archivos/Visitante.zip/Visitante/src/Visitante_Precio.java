
public class Visitante_Precio extends Visitante_Equipo{

	@Override
	public void visitarDisco(Disco d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visitarBus(Bus b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visitarTarjeta(Tarjeta t) {
		// TODO Auto-generated method stub
		
	}

}
