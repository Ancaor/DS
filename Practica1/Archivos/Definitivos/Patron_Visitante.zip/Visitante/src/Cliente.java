import java.util.Random;

public class Cliente {
	
	private static Tipo_Cliente tipo;

	public static void main(String[] args) {
		int pick = new Random().nextInt(Tipo_Cliente.values().length);
	    tipo = Tipo_Cliente.values()[pick];
	    
	    
	    Elemento_Equipo elem1,elem2,elem3;
	    elem1 = new Bus("Bus paralelo",1.40,200);
	    elem2 = new Tarjeta("NVIDIA GTX 2080TI",3000.99,200000);
	    elem3 = new Disco("Seagate",86.87,7200);
	    
	    
	    Visitante_Equipo visitante = new Visitante_Precio();
	    Visitante_Equipo visitante_nombre = new Visitante_Nombre();
	    
	    elem1.aceptar(visitante,tipo);
	    elem1.aceptar(visitante_nombre,tipo);
	    
	    elem2.aceptar(visitante,tipo);
	    elem2.aceptar(visitante_nombre,tipo);
	    
	    elem3.aceptar(visitante,tipo);
	    elem3.aceptar(visitante_nombre,tipo);
	    
	    
	    
	}

}
