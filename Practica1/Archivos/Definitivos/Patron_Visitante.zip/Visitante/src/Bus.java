
public class Bus extends Elemento_Equipo{
	
	public Bus(String nombre,double precio, double potencia) {
		super(nombre);
		this.precioNeto = precio;
		this.potencia = potencia;
	}
	
	@Override
	public void aceptar(Visitante_Equipo visitante, Tipo_Cliente tipo) {
		visitante.visitarEquipo(this, tipo);
		
	}

	@Override
	public double potencia() {
		// TODO Auto-generated method stub
		return potencia;
	}

	@Override
	public double precioNeto() {
		// TODO Auto-generated method stub
		return precioNeto;
	}





}
