
public class Visitante_Nombre extends Visitante_Equipo {

	@Override
	public void visitarEquipo(Elemento_Equipo elem, Tipo_Cliente tipo) {
	System.out.println("El nombre del equipo visitado es: " + elem.nombre);		
	}

}
