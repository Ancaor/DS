
public class Visitante_Precio extends Visitante_Equipo{

	@Override
	public void visitarEquipo(Elemento_Equipo elem, Tipo_Cliente tipo) {
		double precio_neto = elem.precioNeto();
		
		switch(tipo) {
		case VIP : precio_neto = precio_neto - (precio_neto * 0.10);break;
		case MAYORISTA : precio_neto = precio_neto - (precio_neto * 0.15);break;
		case SIN_DESCUENTO : break;
		}
		
		System.out.println("El precio para el cliente " + tipo +" es: " + precio_neto);
		
	}


}
