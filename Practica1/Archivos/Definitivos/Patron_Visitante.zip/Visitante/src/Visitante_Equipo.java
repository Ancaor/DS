
public abstract class Visitante_Equipo {
	public abstract void visitarEquipo (Elemento_Equipo elem , Tipo_Cliente tipo);
}
