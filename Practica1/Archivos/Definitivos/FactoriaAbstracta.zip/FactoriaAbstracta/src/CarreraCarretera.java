import java.util.Random;

public class CarreraCarretera extends Carrera {
	
	public CarreraCarretera(int numCorredores) {
		for(int i=0;i<numCorredores;i++) {
			bicis.add(new Bicicleta(TC.CARRETERA));
		}
	}
	
	
	@Override
	public void run() {
		Random rnd = new Random();
		int eliminado = Math.abs(rnd.nextInt() % bicis.size());
	
		
		if(bicis.size() <= 10)
			bicis.remove(eliminado);
		else {
			int numeroEliminados = (bicis.size() * 10)/100;
			
			for(int i=0;i<numeroEliminados;i++) {
				bicis.remove(eliminado);
				eliminado = Math.abs(rnd.nextInt() % bicis.size());
			}
		}
		
	}
	
}
