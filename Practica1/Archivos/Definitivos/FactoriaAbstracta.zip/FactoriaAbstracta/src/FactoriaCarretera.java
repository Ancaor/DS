

public class FactoriaCarretera implements FactoriaCarrera{

	@Override
	public Carrera crearCarrera(int numCorredores) {
		return new CarreraCarretera(numCorredores);
	}
	
}
