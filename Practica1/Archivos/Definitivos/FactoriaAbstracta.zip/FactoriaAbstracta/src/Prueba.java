
public class Prueba {
	public static void main(String[] args) {
		final long DURACIONMAXIMA = 60000;
		
		FactoriaCarrera factoria;
		
		factoria = new FactoriaCarretera();
		Carrera unaCarrera = factoria.crearCarrera(10);
		
		factoria = new FactoriaMontana();
		Carrera otraCarrera = factoria.crearCarrera(5);
		
		long initialTime = System.currentTimeMillis();
		
		unaCarrera.start();
		otraCarrera.start();
		
		try {
			unaCarrera.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	try {
    		otraCarrera.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	//Tiempo en el que terminan las hebras
    	long finalTime = System.currentTimeMillis();
    	
    	//Ajusto el tiempo de parada
    	
    	long interTime = ((finalTime - initialTime)/1000);

    	
    	long parada = DURACIONMAXIMA - interTime;
    	
    	System.out.println("****************COMIENZA LA CARRERA*****************************");
    	
    	//Hacemos el para ajustado a 60 segundos
		try{
			Thread.sleep(parada);
		}catch (InterruptedException ex){
			Thread.currentThread().interrupt();
		}
		
		System.out.println("Fin de carrera");
		
	}
}
