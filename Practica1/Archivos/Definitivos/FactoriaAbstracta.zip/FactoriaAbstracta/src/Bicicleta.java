
public class Bicicleta {
	private TC tipoBicicleta;
	
	public Bicicleta(TC tipo) {
		tipoBicicleta = tipo;
	}
	
	public TC getTipo() {
		return tipoBicicleta;
	}
	
	public void setTipo(TC tipo) {
		tipoBicicleta = tipo;
	}
	
	@Override
	public String toString() {
		return "bicicleta-"+tipoBicicleta;
	}
	
}
