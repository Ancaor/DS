
public class PantallaTemperatura implements Observador{

	@Override
	public void manejarEvento() {
		int tempe = ObservableTemperatura.getTemperatura();
		System.out.println("Estoy con evento de PantallaTemperatura: " + tempe + "�C");
		System.out.println("Estoy con evento de PantallaTemperatura: " + ((tempe*1.8)+32)  +"�F");
		Pantalla.observarTemperatura();
	}
}
