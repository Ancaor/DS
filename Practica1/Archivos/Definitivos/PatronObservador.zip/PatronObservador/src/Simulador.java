import java.util.Random;

public class Simulador extends Thread{
	
	@Override
	public void run() {
		Random r = new Random (45); int temperatura;
		while(true) {
			temperatura = r.nextInt((45 - 15) + 1) + 15; // min y max preestablecidos a 15 y 45 grados.
			try{sleep(600);}
			catch(java.lang.InterruptedException e) {
				e.printStackTrace();
			}
			ObservableTemperatura.setTemperatura(temperatura);
			ObservableTemperatura.notificarObservador();
		}
	}
}
