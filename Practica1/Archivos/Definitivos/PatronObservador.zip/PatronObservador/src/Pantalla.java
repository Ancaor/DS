import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

public class Pantalla extends JFrame implements Runnable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static JLabel temperatura = new JLabel();

	private static int temperatura_observada;
	
	public Pantalla() {
		
		setTitle("Programa test simple");
	    setSize(400,400);
	    Panel panelSuperior= new Panel();
	    panelSuperior.setLayout(new BorderLayout());
	    getContentPane().add(panelSuperior);//para acceder a JRootPane
	    panelSuperior.add(temperatura, BorderLayout.NORTH);	
	    setVisible(true);
	    
	    this.addWindowListener(new WindowAdapter() {
	    	public void windowClosing(WindowEvent e) {
	    		System.exit(0);
	    	}
	    });
	}	
	
	
	@Override
	public void run() {
		while(true) {
		refrescarPantalla();
		}
	}
	
	public static void refrescarPantalla() {
		temperatura.setText("Temperatura en Celsius="+String.valueOf(temperatura_observada) + "   "+ "Temperatura en Fahrenheit="+String.valueOf((temperatura_observada*1.8)+32));
	}

	public static void observarTemperatura() {
		temperatura_observada = ObservableTemperatura.getTemperatura();
	}
		
	

}
