package Controles;

public enum Estados {
ACELERAR, MANTENER, REINICIAR, APAGAR, FRENAR, SOLTARFRENO
}
