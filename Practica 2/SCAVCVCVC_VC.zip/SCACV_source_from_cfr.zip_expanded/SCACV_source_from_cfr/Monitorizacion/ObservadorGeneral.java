/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorGeneral implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorGeneral(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_revision = observable.getVehiculo().getNivel(TipoNivel.GENERAL).getKmActual();
        double kilometros_revision =  observable.getVehiculo().getDistanciaRecorrida() - kilometro_revision;
        //System.out.println("kilometros deposito:" + kilometros_deposito);
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.GENERAL).getKmMax();
     //   System.out.println("kilometros max:" + kilometros_maximos);
        double porcentaje = (kilometros_revision * 100)/kilometros_maximos;
       // System.out.println(porcentaje);
        double aux = 100.0 - porcentaje;
       // System.out.println(aux + "%");
        medidor.setValue((int) aux);
        
    }
    
}
