/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import javax.swing.JButton;
import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorVelocidad implements I_Observador{

    private Observable observable;
    private JTextField velocimetro;
    private JButton botonArrancar;
    
    
    public ObservadorVelocidad(Observable observable, JTextField velocimetro, JButton botonArrancar){
	this.observable = observable;
	this.velocimetro = velocimetro;
        this.observable.addObservador(this);
        this.botonArrancar = botonArrancar;
    }
    
    @Override
    public void update() {
        int velocidad = (int)this.observable.getVehiculo().getVelocidad();
        velocimetro.setText(String.valueOf(velocidad));
        
        if(velocidad == 0){
            botonArrancar.setEnabled(true);
        }else botonArrancar.setEnabled(false);
    }
    
}
