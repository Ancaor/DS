/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controles;

/**
 *
 * @author ancaor
 */
public class Nivel_General extends Nivel{
    private final int kmMax = 30000;
    /**
     *
     */
    public Nivel_General(){
        super(TipoNivel.GENERAL);
    }
    
    @Override
    public int getKmMax() {
        return kmMax;
    }
    
}
