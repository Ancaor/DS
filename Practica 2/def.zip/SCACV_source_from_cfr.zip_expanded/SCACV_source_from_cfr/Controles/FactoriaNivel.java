/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controles;

/**
 *
 * @author ancaor
 */
public class FactoriaNivel {
    public static Nivel crearNivel(TipoNivel t){
        Nivel elNivel = null;
        switch(t){
            case COMBUSTIBLE:
                elNivel = new NIvel_Combustible();
                break;
            case FRENOS:
                elNivel = new Nivel_Frenos();
                break;
            case GENERAL:
                elNivel = new Nivel_General();
                break;
            case ACEITE:
                elNivel = new Nivel_Aceite();
                break;
        }
        
        return elNivel;
    }
}
