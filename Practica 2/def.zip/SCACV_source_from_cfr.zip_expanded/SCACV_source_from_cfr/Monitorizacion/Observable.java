/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import Vehiculo.Vehiculo;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 *
 * @author ancaor
 */
public class Observable implements I_Observable,Runnable {
    private ArrayList<I_Observador> observadores;
	private Thread thread;
	
	private Vehiculo vehiculo;
        
        

	public Observable(Vehiculo uncoche){
		this.observadores = new ArrayList<I_Observador>();
		this.vehiculo = uncoche;
	}
        
        @Override
        public void addObservador(I_Observador observador) {
            observadores.add(observador);
        }

        @Override
        public void removeObservador(I_Observador observador) {
            observadores.remove(observador);
        }
        
	public Vehiculo getVehiculo(){
		return vehiculo;
	}
	
	private void notificar(){

		for(I_Observador observador : observadores){
			observador.update();
		}
	}
	
	public void start(){
		thread = new Thread(this);
		thread.start();
	}
	
	public void run(){
		synchronized (this){
			while(true){
				try{
					this.wait(15);
					if(vehiculo.getEstadoMotor() == 1){
						notificar();
					}
				}catch (InterruptedException ex){
					Logger.getLogger("Se produjo una excepción en la ejecucion");
				}
			}
		}
	}

    
}
