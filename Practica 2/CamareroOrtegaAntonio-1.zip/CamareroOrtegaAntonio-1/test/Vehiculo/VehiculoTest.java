package Vehiculo;

import static org.junit.Assert.*;

import org.junit.Test;

import Controles.Nivel;
import Controles.TipoNivel;

public class VehiculoTest { 

	@Test
	public void testGetDistanciaRecorrida() {
		Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getDistanciaRecorrida(),0.001);
	}

	@Test
	public void testGetVelocidad() {
Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getVelocidad(),0.001);
	}

	@Test
	public void testGetEstadoMotor() {
		Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getEstadoMotor(),0.001);
	}

	@Test
	public void testGetFactorAceleracion() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.resetFactorAceleracion();
		assertEquals(0.0,v.getfactorAceleracion(),0.001);
	}

	@Test
	public void testAumentarFactorAceleracion() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.resetFactorAceleracion();
		v.aumentarFactorAceleracion(0.3);
		assertEquals(0.3,v.getfactorAceleracion(),0.001);
	}

	@Test
	public void testDisminuirFactorAceleracion() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.aumentarFactorAceleracion(0.3);
		v.disminuirFactorAceleracion(0.1);
		assertEquals(0.2,v.getfactorAceleracion(),0.001);
	}

	@Test
	public void testResetFactorAceleracion() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.resetFactorAceleracion();
		v.aumentarFactorAceleracion(0.3);
		assertEquals(0.3,v.getfactorAceleracion(),0.001);
		v.resetFactorAceleracion();
		assertEquals(0,v.getfactorAceleracion(),0.001);
	}

	@Test
	public void testGetNivel() {
		Vehiculo v = Vehiculo.getVehiculo();
		Nivel a = v.getNivel(TipoNivel.ACEITE);
		assertEquals(TipoNivel.ACEITE,a.getTipo());
	}


}
