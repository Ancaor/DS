package Controles;

import static org.junit.Assert.*;

import org.junit.Test;

import Vehiculo.Vehiculo;

public class CalculadorVelocidadTest {
	Vehiculo v = Vehiculo.getVehiculo();
	CalculadorVelocidad calc = new CalculadorVelocidad(v);

	@Test
	public void testGetVelocidad() {
		assertEquals(0,calc.getVelocidad(),0.0001);
	}

	@Test
	public void testEqualsObject() {
		CalculadorVelocidad calc2 = new CalculadorVelocidad(v);
		
		assertEquals(calc,calc2);
	}

}
