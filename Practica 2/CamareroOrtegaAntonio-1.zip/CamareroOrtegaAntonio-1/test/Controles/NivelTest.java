package Controles;

import static org.junit.Assert.*;

import org.junit.Test;

public class NivelTest {
	
	Nivel nivelAceite = new Nivel_Aceite();
	Nivel nivelGasolina = new Nivel_Combustible();
	Nivel nivelFrenos = new Nivel_Frenos();
	Nivel nivelGeneral = new Nivel_General();
	

	@Test
	public void testGetKmMax() {
		assertEquals(20000,nivelAceite.getKmMax());
		assertEquals(600,nivelGasolina.getKmMax());
		assertEquals(20000,nivelFrenos.getKmMax());
		assertEquals(30000,nivelGeneral.getKmMax());
	}

	@Test
	public void testGetKmActual() {
		assertEquals(0,nivelAceite.getKmActual());
		assertEquals(0,nivelGasolina.getKmActual());
		assertEquals(0,nivelFrenos.getKmActual());
		assertEquals(0,nivelGeneral.getKmActual());
	}

	@Test
	public void testGetTipo() {
		assertEquals(TipoNivel.ACEITE,nivelAceite.getTipo());
		assertEquals(TipoNivel.COMBUSTIBLE,nivelGasolina.getTipo());
		assertEquals(TipoNivel.FRENOS,nivelFrenos.getTipo());
		assertEquals(TipoNivel.GENERAL,nivelGeneral.getTipo());
	}

	@Test
	public void testSetKilometro() {
		nivelGasolina.setKilometro(120);
		assertEquals(120,nivelGasolina.getKmActual());
	}

	@Test
	public void testEqualsObject() {
		Nivel aux = new Nivel_Combustible();
		Nivel aux2 = new Nivel_Combustible();
		aux.setKilometro(120);
		aux2.setKilometro(120);
		
		assertEquals(aux,aux2);
		
	}

}
