package Controles;

/**
 *
 * @author ancaor
 */
public class FactoriaNivel {
    public static Nivel crearNivel(TipoNivel t){
        Nivel elNivel = null;
        switch(t){
            case COMBUSTIBLE:
                elNivel = new Nivel_Combustible();
                break;
            case FRENOS:
                elNivel = new Nivel_Frenos();
                break;
            case GENERAL:
                elNivel = new Nivel_General();
                break;
            case ACEITE:
                elNivel = new Nivel_Aceite();
                break;
        }
        
        return elNivel;
    }
}
