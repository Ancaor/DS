package Controles;

import Vehiculo.Vehiculo;

public class CalculadorVelocidad {
    private Vehiculo vehiculo;
    private double velocidad;

    public CalculadorVelocidad(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
        this.velocidad = 0.0;
    }

    double getVelocidad() {
        this.velocidad = this.vehiculo.getVelocidad();
        return this.velocidad;
    }
    
    @Override
    public boolean equals(Object obj) {
    	boolean resultado = false;
    	CalculadorVelocidad aux;
    	
    	if(obj instanceof CalculadorVelocidad) {
    		aux = (CalculadorVelocidad) obj;
    		if(this.velocidad == aux.velocidad) {
    			resultado = true;
    		}
    	}
    	
    	return resultado;
    }
}

