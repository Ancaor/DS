package Controles;

/**
 *
 * @author ancaor
 */
public class Nivel_Frenos extends Nivel{
    private final int kmMax = 20000;
    /**
     *
     */
    public Nivel_Frenos(){
        super(TipoNivel.FRENOS);
    }
    
    @Override
    public int getKmMax() {
        return kmMax;
    }
    
}
