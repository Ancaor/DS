package Controles;

/**
 *
 * @author ancaor
 */
public class Nivel_Combustible extends Nivel{
    private final int kmMax = 600;
    /**
     *
     */
    public Nivel_Combustible(){
        super(TipoNivel.COMBUSTIBLE);
    }
    
    @Override
    public int getKmMax() {
        return kmMax;
    }
    
}
