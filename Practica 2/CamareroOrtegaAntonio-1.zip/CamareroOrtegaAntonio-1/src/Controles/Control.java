package Controles;

import Controles.Acelerador;
import Controles.CalculadorVelocidad;

public class Control extends Thread {
	
	
	
    public final double CteACELERACION = 0.1;
    
    private Acelerador acelerador;
    private CalculadorVelocidad calculadorVelocidad;
    private Estados estado;
    private Estados estadoAnterior;
    private double velocidadMantener;
    private boolean salir;

    public Control(Acelerador acelerador, CalculadorVelocidad calculadorVelocidad) {
        this.acelerador = acelerador;
        this.calculadorVelocidad = calculadorVelocidad;
        this.estado = Estados.APAGAR;
        this.estadoAnterior = Estados.APAGAR;
        this.velocidadMantener = 0.0;
    }

    public double getVelocidadMantener() {
        return this.velocidadMantener;
    }

    public Estados getEstado() {
        return this.estado;
    }

    public void setVelocidadMantener() {
        this.velocidadMantener = this.calculadorVelocidad.getVelocidad();
    }

    public void cambiaEstado(Estados estadoNuevo) {
        this.estadoAnterior = this.estado;
        this.estado = estadoNuevo;
    }

    public void recuperarEstado() {
    	if(this.estadoAnterior == Estados.ACELERAR)
    		
    		this.estado = this.estadoAnterior;
        else 
        	this.estado = Estados.APAGAR;
    }

    public void mantener() {
        double diferencia = this.calculadorVelocidad.getVelocidad() - this.velocidadMantener;
        if (diferencia > 0.0) {
            this.acelerador.desacelerar(diferencia);
        }
        if (diferencia < 0.0) {
            this.acelerador.acelerar(-diferencia);
        }
    }

    public void iniciarHebra() {
        this.salir = false;
        if (!this.isAlive()) {
            this.start();
        }
    }

    public void salirHebra() {
        this.salir = true;
    }

    public void apagarMotor() {
        this.velocidadMantener = 0.0;
    }

    public void run()
    {
      while (!salir)
      {
        switch (estado)
        {
        case ACELERAR: 
          while (estado == Estados.ACELERAR)
          {
            try
            {
              acelerador.acelerar(CteACELERACION);
              sleep(100);
            } catch (InterruptedException localInterruptedException) {}
          }
          break;
        case MANTENER: 
          while (estado == Estados.MANTENER)
          {
            try
            {
              mantener();
              sleep(100);
            } catch (InterruptedException localInterruptedException1) {}
          }
          break;
        case REINICIAR: 
          while (estado == Estados.REINICIAR)
          {
            try
            {
              do
              {
                acelerador.acelerar(CteACELERACION);
                sleep(100);
              } while ((calculadorVelocidad.getVelocidad() <= velocidadMantener) && (estado == Estados.REINICIAR));


              if (estado == Estados.REINICIAR) {
                cambiaEstado(Estados.MANTENER);
              }
            } catch (InterruptedException localInterruptedException2) {}
          }
          break;
        case APAGAR: 
          acelerador.apagar();
          while (estado == Estados.APAGAR)
          {
            try
            {

              sleep(100);
            } catch (InterruptedException localInterruptedException3) {}
          }
          break;
        case FRENAR: 
          acelerador.apagar();
          while (estado == Estados.FRENAR)
          {
            try
            {

              sleep(100);
            }
            catch (InterruptedException localInterruptedException4) {}
          }
        }
      }
    }
    
    @Override
    public boolean equals(Object obj) {
    	boolean resultado=false;
    	Control aux;
    	
    	if(obj instanceof Control) {
    		aux = (Control)obj;
    		if((this.estado == aux.estado) && (this.estadoAnterior == aux.estadoAnterior) && (this.salir == aux.salir) && (this.velocidadMantener == aux.velocidadMantener)) {
    			resultado = true;
    		}
    	}
    	
    	return resultado;
    	
    }
    
    
    
}

