package Monitorizacion;


import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorVelocidadMedia implements I_Observador{

    private Observable observable;
    private JTextField visorVelocidadMedia;
    
    
    
    public ObservadorVelocidadMedia(Observable observable, JTextField visorVelocidadMedia){
	this.observable = observable;
	this.visorVelocidadMedia = visorVelocidadMedia;
        this.observable.addObservador(this);
        
    }
    
    @Override
    public void update() {
        int velocidadMedia = (int)this.observable.getVehiculo().getVelocidadMedia();
        visorVelocidadMedia.setText(String.valueOf(velocidadMedia));
    }
    
}
