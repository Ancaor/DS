/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;


import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorEstadoSCAV implements I_Observador{

    private Observable observable;
    private JTextField visorEstado;
    
    
    
    public ObservadorEstadoSCAV(Observable observable, JTextField visorEstado){
	this.observable = observable;
	this.visorEstado = visorEstado;
        this.observable.addObservador(this);
        
    }
    
    @Override
    public void update() {
        visorEstado.setText(String.valueOf(this.observable.getVehiculo().getControl().getEstado()));
    }
    
}
