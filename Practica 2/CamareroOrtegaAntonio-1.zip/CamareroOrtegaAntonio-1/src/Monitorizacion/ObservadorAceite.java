package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorAceite implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorAceite(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_cambio = observable.getVehiculo().getNivel(TipoNivel.ACEITE).getKmActual();
        int kilometros_cambio =  (int)observable.getVehiculo().getDistanciaRecorrida() - kilometro_cambio;
        
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.ACEITE).getKmMax();
     
        double porcentaje = (kilometros_cambio * 100)/kilometros_maximos;
       
        int aux = 100 - (int)porcentaje;
      
        medidor.setValue((int) aux);
        
    }
    
}
