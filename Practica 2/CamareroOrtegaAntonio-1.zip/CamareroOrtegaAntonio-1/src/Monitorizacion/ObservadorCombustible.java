package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorCombustible implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorCombustible(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_repostaje = observable.getVehiculo().getNivel(TipoNivel.COMBUSTIBLE).getKmActual() ;
        int kilometros_deposito =  (int)observable.getVehiculo().getDistanciaRecorrida() - kilometro_repostaje;
        
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.COMBUSTIBLE).getKmMax();
     
        double porcentaje = (kilometros_deposito * 100)/kilometros_maximos;
       
        int aux = 100 - (int) porcentaje;
       
        medidor.setValue((int) aux);
        
        if(aux <= 0){
            observable.getVehiculo().resetFactorAceleracion();
        }
        
    }
    
}
