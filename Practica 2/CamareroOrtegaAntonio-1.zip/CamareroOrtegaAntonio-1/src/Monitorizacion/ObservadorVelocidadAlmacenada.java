package Monitorizacion;


import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorVelocidadAlmacenada implements I_Observador{

    private Observable observable;
    private JTextField visorVelocidadAlmacenada;
    
    
    
    public ObservadorVelocidadAlmacenada(Observable observable, JTextField visorVelocidadAlmacenada){
	this.observable = observable;
	this.visorVelocidadAlmacenada = visorVelocidadAlmacenada;
        this.observable.addObservador(this);
        
    }
    
    @Override
    public void update() {
        int velocidadAlmacenada = (int)this.observable.getVehiculo().getControl().getVelocidadMantener();
        visorVelocidadAlmacenada.setText(String.valueOf(velocidadAlmacenada));
    }
    
}
