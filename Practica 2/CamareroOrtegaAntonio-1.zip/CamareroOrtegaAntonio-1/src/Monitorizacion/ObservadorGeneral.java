package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorGeneral implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorGeneral(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_revision = observable.getVehiculo().getNivel(TipoNivel.GENERAL).getKmActual();
        int kilometros_revision =  (int)observable.getVehiculo().getDistanciaRecorrida() - kilometro_revision;
        
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.GENERAL).getKmMax();
     
        double porcentaje = (kilometros_revision * 100)/kilometros_maximos;
       
        int aux = 100 - (int)porcentaje;
       
        medidor.setValue((int) aux);
        
    }
    
}
