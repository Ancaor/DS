package Controles;

import static org.junit.Assert.*;

import org.junit.Test;

import Vehiculo.Vehiculo;

public class ControlTest {
	Vehiculo v = Vehiculo.getVehiculo();
	Acelerador a = new Acelerador(v);
	CalculadorVelocidad c = new CalculadorVelocidad(v);

	@Test
	public void testGetVelocidadAutomatica() {
		Control c1 = new Control(a,c);
		assertEquals(0,c1.getVelocidadAutomatica(),0.0001);
	}

	@Test
	public void testGetEstado() {
		Control c1 = new Control(a,c);
		assertEquals(Estados.APAGAR,c1.getEstado());
	}

	@Test
	public void testSetVelocidadAutomatica() {
		Control c1 = new Control(a,c);
		c1.setVelocidadAutomatica();
		assertEquals(c.getVelocidad(),c1.getVelocidadAutomatica(),0.001);
	}

	@Test
	public void testCambiaEstado() {
		Control c1 = new Control(a,c);
		c1.cambiaEstado(Estados.ACELERAR);
		assertEquals(Estados.ACELERAR,c1.getEstado());
	}

	@Test
	public void testRecuperarEstado() {
		Control c1 = new Control(a,c);
		c1.cambiaEstado(Estados.ACELERAR);
		c1.cambiaEstado(Estados.APAGAR);
		c1.recuperarEstado();
		assertEquals(Estados.ACELERAR,c1.getEstado());
	}

	@Test
	public void testEqualsObject() {
		Control c1 = new Control(a,c);
		Control c2 = new Control(a,c);
		
		assertEquals(c1,c2);
	}

}
