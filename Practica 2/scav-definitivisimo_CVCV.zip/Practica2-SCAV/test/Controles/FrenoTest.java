package Controles;

import static org.junit.Assert.*;

import org.junit.Test;

import Vehiculo.Vehiculo;

public class FrenoTest {
	Vehiculo v = Vehiculo.getVehiculo();
	Acelerador a = new Acelerador(v);
	CalculadorVelocidad cv = new CalculadorVelocidad(v);
	Control c = new Control(a,cv);

	@Test
	public void testGetEstado() {
		Freno f = new Freno(v,c);
		assertEquals(Estados.SOLTARFRENO,f.getEstado());
	}

	@Test
	public void testSetEstado() {
		Freno f = new Freno(v,c);
		f.setEstado();
		assertEquals(Estados.FRENAR,f.getEstado());
	}

	@Test
	public void testFrenar() {
		Freno f = new Freno(v,c);
		f.frenar();
		assertEquals(Estados.FRENAR,f.getEstado());
	}

	@Test
	public void testSoltarFreno() {
		Freno f = new Freno(v,c);
		f.soltarFreno();;
		assertEquals(Estados.SOLTARFRENO,f.getEstado());
	}

}
