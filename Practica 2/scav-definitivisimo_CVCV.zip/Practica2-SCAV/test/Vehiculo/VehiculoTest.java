package Vehiculo;

import static org.junit.Assert.*;

import org.junit.Test;

import Controles.Nivel;
import Controles.TipoNivel;

public class VehiculoTest {

	@Test
	public void testGetDistanciaRecorrida() {
		Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getDistanciaRecorrida(),0.001);
	}

	@Test
	public void testGetVelocidad() {
Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getVelocidad(),0.001);
	}

	@Test
	public void testGetEstadoMotor() {
		Vehiculo v = Vehiculo.getVehiculo();
		
		assertEquals(0,v.getEstadoMotor(),0.001);
	}

	@Test
	public void testGetInyector() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.cerrarInyector();
		assertEquals(0.0,v.getInyector(),0.001);
	}

	@Test
	public void testAumentarInyector() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.cerrarInyector();
		v.aumentarInyector(30);
		assertEquals(30,v.getInyector(),0.001);
	}

	@Test
	public void testDisminuirInyector() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.aumentarInyector(30);
		v.disminuirInyector(10);
		assertEquals(20,v.getInyector(),0.001);
	}

	@Test
	public void testCerrarInyector() {
		Vehiculo v = Vehiculo.getVehiculo();
		v.cerrarInyector();
		v.aumentarInyector(30);
		assertEquals(30,v.getInyector(),0.001);
		v.cerrarInyector();
		assertEquals(0,v.getInyector(),0.001);
	}

	@Test
	public void testGetNivel() {
		Vehiculo v = Vehiculo.getVehiculo();
		Nivel a = v.getNivel(TipoNivel.ACEITE);
		assertEquals(TipoNivel.ACEITE,a.getTipo());
	}


}
