package Controles;

/**
 *
 * @author ancaor
 */
public enum TipoNivel {
    COMBUSTIBLE,ACEITE,FRENOS,GENERAL;
}
