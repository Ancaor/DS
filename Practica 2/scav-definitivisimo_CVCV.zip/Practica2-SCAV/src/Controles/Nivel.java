package Controles;

/**
 *
 * @author ancaor
 */
public abstract class Nivel {
    
    private TipoNivel tipo;
    private int km_actual;
    
    public Nivel(TipoNivel tipo){
        km_actual = 0;
        this.tipo = tipo;
    }
    
    public abstract int getKmMax();
    
    public int getKmActual(){
        return km_actual;
    }
    
    public TipoNivel getTipo(){
        return tipo;
    }

    public void setKilometro(double distanciaRecorrida) {
        km_actual = (int) distanciaRecorrida;
    }
    
    @Override
	public boolean equals(Object obj) {
		boolean result = false;
		Nivel aux;
		
		if(obj instanceof Nivel){
			aux = (Nivel) obj;
			if((this.tipo == aux.tipo) && (this.km_actual == aux.km_actual) && (this.getKmMax() == aux.getKmMax()))
						result = true;
		}
		return result;
	}
    
}
