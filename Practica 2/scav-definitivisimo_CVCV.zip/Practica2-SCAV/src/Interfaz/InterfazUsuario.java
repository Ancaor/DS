package Interfaz;

import Controles.Control;
import Controles.Estados;
import Controles.Freno;
import Controles.Palanca;
import Controles.TipoNivel;
import Monitorizacion.*;
import Vehiculo.Vehiculo;

/**
 *
 * @author ancaor
 */
public class InterfazUsuario extends javax.swing.JApplet {

   
    private Vehiculo vehiculo;
	
    private Control control;
    private Palanca palanca;
    private Freno freno;
    
    
    private Observable observable;
    
    @Override
    public void init() {
        
        this.vehiculo = Vehiculo.getVehiculo();
        this.control = this.vehiculo.getControl();
        this.palanca = this.vehiculo.getPalanca();
        this.freno = this.vehiculo.getFreno();
        

        /* Create and display the applet */
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {
                public void run() {
                    initComponents();
                    
                    vehiculo = Vehiculo.getVehiculo();
                    observable = new Observable(vehiculo);
                    
                    new ObservadorCombustible(observable,NivelCombustible);
                    new ObservadorVelocidad(observable,Velocimetro,BotonArrancar);
                    new ObservadorDistancia(observable,Kilometros);
                    new ObservadorAceite(observable,NIvelAceite);
                    new ObservadorGeneral(observable,NivelGeneral);
                    new ObservadorFrenos(observable,NivelFrenos);
                    new ObservadorVelocidadMedia(observable,VelocidadMedia);
                    new ObservadorVelocidadAlmacenada(observable,VelocidadAlmacenada);
                    new ObservadorEstadoSCAV(observable,EstadoSCAV);
                    observable.start();
                    
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        this.resize(900,500);
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BotonAcelerar = new javax.swing.JButton();
        BotonParar = new javax.swing.JButton();
        BotonMantener = new javax.swing.JButton();
        BotonReiniciar = new javax.swing.JButton();
        BotonArrancar = new javax.swing.JButton();
        BotonFrenar = new javax.swing.JButton();
        NivelCombustible = new javax.swing.JProgressBar();
        jLabel1 = new javax.swing.JLabel();
        BotonRepostar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Velocimetro = new javax.swing.JTextField();
        Kilometros = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        VelocidadMedia = new javax.swing.JTextField();
        NIvelAceite = new javax.swing.JProgressBar();
        NivelFrenos = new javax.swing.JProgressBar();
        NivelGeneral = new javax.swing.JProgressBar();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BotonAceite = new javax.swing.JButton();
        BotonFrenos = new javax.swing.JButton();
        BotonGeneral = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        EstadoSCAV = new javax.swing.JTextField();
        VelocidadAlmacenada = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(1000, 1000));
        BotonAcelerar.setEnabled(false);
        BotonMantener.setEnabled(false);
        BotonReiniciar.setEnabled(false);
        BotonParar.setEnabled(false);
        NivelCombustible.setVisible(false);
        NivelFrenos.setVisible(false);
        NivelGeneral.setVisible(false);
        NIvelAceite.setVisible(false);

        BotonAcelerar.setText("Acelerar");
        BotonAcelerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAcelerarActionPerformed(evt);
            }
        });

        BotonParar.setText("Parar");
        BotonParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPararActionPerformed(evt);
            }
        });

        BotonMantener.setText("Mantener");
        BotonMantener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonMantenerActionPerformed(evt);
            }
        });

        BotonReiniciar.setText("Reiniciar");
        BotonReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReiniciarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(BotonAcelerar)
                    .addComponent(BotonReiniciar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(BotonParar, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addComponent(BotonMantener)
                .addGap(32, 32, 32))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BotonAcelerar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BotonParar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonMantener, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(71, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BotonReiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        BotonArrancar.setText("Arrancar");
        BotonArrancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonArrancarActionPerformed(evt);
            }
        });

        BotonFrenar.setText("Frenar");
        BotonFrenar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BotonFrenarMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                BotonFrenarMouseReleased(evt);
            }
        });
        

        jLabel1.setText("Aceite");

        BotonRepostar.setText("Repostar");
        BotonRepostar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRepostarMouseClicked(evt);
            }
        });

        Velocimetro.setText("0");

        Kilometros.setText("0");
        

        jLabel2.setText("Velocidad (km/h) :");

        jLabel3.setText("Kilometros recorridos :");

        jLabel7.setText("Velocidad media");

        VelocidadMedia.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(Kilometros, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(VelocidadMedia, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Velocimetro))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Velocimetro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Kilometros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(VelocidadMedia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );

        jLabel4.setText("Combustible");

        jLabel5.setText("Frenos");

        jLabel6.setText("General");

        BotonAceite.setText("Cambiar Aceite");
        
        BotonAceite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAceiteActionPerformed(evt);
            }
        });

        BotonFrenos.setText("Cambiar Frenos");
        BotonFrenos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonFrenosMouseClicked(evt);
            }
        });

        BotonGeneral.setText("Revision completa");
        BotonGeneral.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonGeneralMouseClicked(evt);
            }
        });

        jLabel8.setText("EstadoSCAV: ");

        jLabel9.setText("Velocidad Almacenada: ");

        EstadoSCAV.setText("APAGADO");

        VelocidadAlmacenada.setText("0");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(EstadoSCAV, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(VelocidadAlmacenada, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(243, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(EstadoSCAV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(VelocidadAlmacenada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotonArrancar)
                            .addComponent(BotonFrenar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel4))
                            .addComponent(NivelCombustible, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jLabel1))
                            .addComponent(NIvelAceite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jLabel5))
                            .addComponent(NivelFrenos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addComponent(jLabel6))
                            .addComponent(NivelGeneral, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotonRepostar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonAceite, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonFrenos, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonGeneral)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addComponent(BotonArrancar)
                                .addGap(38, 38, 38)
                                .addComponent(BotonFrenar))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(6, 6, 6)
                                .addComponent(NivelCombustible, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jLabel1)
                                .addGap(7, 7, 7)
                                .addComponent(NIvelAceite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jLabel5)
                                .addGap(6, 6, 6)
                                .addComponent(NivelFrenos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6)
                                .addGap(6, 6, 6)
                                .addComponent(NivelGeneral, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(BotonRepostar)
                                .addGap(28, 28, 28)
                                .addComponent(BotonAceite)
                                .addGap(22, 22, 22)
                                .addComponent(BotonFrenos)
                                .addGap(28, 28, 28)
                                .addComponent(BotonGeneral)))
                        .addGap(10, 10, 10)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(107, 107, 107))
        );
    }


    private void BotonArrancarActionPerformed(java.awt.event.ActionEvent evt) {
            this.vehiculo.getClass();
            if (this.vehiculo.getEstadoMotor() == 0) {
                System.out.println("entraa");
                this.vehiculo.arrancar();
                this.control.iniciarHebra();
                BotonArrancar.setText("Apagar");
                BotonRepostar.setEnabled(false);
                BotonAcelerar.setEnabled(true);
                NivelCombustible.setVisible(true);
                NivelFrenos.setVisible(true);
                NivelGeneral.setVisible(true);
                NIvelAceite.setVisible(true);
                BotonGeneral.setEnabled(false);
                BotonFrenos.setEnabled(false);
                BotonAceite.setEnabled(false);
                
            } else if (this.control.getEstado() == Estados.APAGAR) {
                this.vehiculo.pararMotor();
                this.control.apagarMotor();
                BotonArrancar.setText("Arrancar");
                BotonRepostar.setEnabled(true);
                BotonAcelerar.setEnabled(false);
                BotonMantener.setEnabled(false);
                BotonReiniciar.setEnabled(false);
                BotonParar.setEnabled(false);
                NivelCombustible.setVisible(false);
                NivelFrenos.setVisible(false);
                NivelGeneral.setVisible(false);
                NIvelAceite.setVisible(false);
                BotonGeneral.setEnabled(true);
                BotonFrenos.setEnabled(true);
                BotonAceite.setEnabled(true);
            }        
            
    
    }

    private void BotonFrenarMousePressed(java.awt.event.MouseEvent evt) {
        this.freno.frenar();
        BotonFrenar.setText("Frenando");
        if("ACELERAR".equals(EstadoSCAV.getText())){
            BotonMantener.setEnabled(true);
            BotonParar.setEnabled(false);
            BotonReiniciar.setEnabled(false);
            BotonAcelerar.setEnabled(false);
        }else{
            BotonMantener.setEnabled(false);
            BotonParar.setEnabled(false);
            BotonReiniciar.setEnabled(true);
            BotonAcelerar.setEnabled(true);
        }
        
    }

    private void BotonFrenarMouseReleased(java.awt.event.MouseEvent evt) {
        this.freno.soltarFreno();
        BotonFrenar.setText("Frenar");
    }

    private void BotonRepostarMouseClicked(java.awt.event.MouseEvent evt) {
        this.vehiculo.getClass();
        this.vehiculo.rellenarNivel(TipoNivel.COMBUSTIBLE);
    }

    private void BotonFrenosMouseClicked(java.awt.event.MouseEvent evt) {
        this.vehiculo.rellenarNivel(TipoNivel.FRENOS);
    }

    private void BotonGeneralMouseClicked(java.awt.event.MouseEvent evt) {
        this.vehiculo.rellenarNivel(TipoNivel.GENERAL);
    }

    private void BotonAceiteActionPerformed(java.awt.event.ActionEvent evt) {
        this.vehiculo.rellenarNivel(TipoNivel.ACEITE);
    }


    private void BotonMantenerActionPerformed(java.awt.event.ActionEvent evt) {
        this.palanca.setPosicion(Estados.MANTENER);
        BotonAcelerar.setEnabled(true);
        BotonMantener.setEnabled(false);
        BotonReiniciar.setEnabled(false);
        BotonParar.setEnabled(true);
    }

    private void BotonAcelerarActionPerformed(java.awt.event.ActionEvent evt) {
        this.palanca.setPosicion(Estados.ACELERAR);
        BotonAcelerar.setEnabled(false);
        BotonMantener.setEnabled(true);
        BotonReiniciar.setEnabled(false);
        BotonParar.setEnabled(false);
    }

    private void BotonPararActionPerformed(java.awt.event.ActionEvent evt) {
        this.palanca.setPosicion(Estados.APAGAR);
        BotonAcelerar.setEnabled(true);
        BotonMantener.setEnabled(false);
        BotonReiniciar.setEnabled(true);
        BotonParar.setEnabled(false);
    }

    private void BotonReiniciarActionPerformed(java.awt.event.ActionEvent evt) {
        this.palanca.setPosicion(Estados.REINICIAR);
        BotonAcelerar.setEnabled(true);
        BotonMantener.setEnabled(false);
        BotonReiniciar.setEnabled(false);
        BotonParar.setEnabled(true);
    }


    private javax.swing.JButton BotonAceite;
    private javax.swing.JButton BotonAcelerar;
    private javax.swing.JButton BotonArrancar;
    private javax.swing.JButton BotonFrenar;
    private javax.swing.JButton BotonFrenos;
    private javax.swing.JButton BotonGeneral;
    private javax.swing.JButton BotonMantener;
    private javax.swing.JButton BotonParar;
    private javax.swing.JButton BotonReiniciar;
    private javax.swing.JButton BotonRepostar;
    private javax.swing.JTextField EstadoSCAV;
    private javax.swing.JTextField Kilometros;
    private javax.swing.JProgressBar NIvelAceite;
    private javax.swing.JProgressBar NivelCombustible;
    private javax.swing.JProgressBar NivelFrenos;
    private javax.swing.JProgressBar NivelGeneral;
    private javax.swing.JTextField VelocidadAlmacenada;
    private javax.swing.JTextField VelocidadMedia;
    private javax.swing.JTextField Velocimetro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
}
