/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorCombustible implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorCombustible(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_repostaje = observable.getVehiculo().getNivel(TipoNivel.COMBUSTIBLE).getKmActual() ;
        int kilometros_deposito =  (int)observable.getVehiculo().getDistanciaRecorrida() - kilometro_repostaje;
        //System.out.println("kilometros deposito:" + kilometros_deposito);
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.COMBUSTIBLE).getKmMax();
     //   System.out.println("kilometros max:" + kilometros_maximos);
        double porcentaje = (kilometros_deposito * 100)/kilometros_maximos;
       // System.out.println(porcentaje);
        int aux = 100 - (int) porcentaje;
       // System.out.println(aux + "%");
        medidor.setValue((int) aux);
        
        if(aux <= 0){
            observable.getVehiculo().cerrarInyector();
        }
        
    }
    
}
