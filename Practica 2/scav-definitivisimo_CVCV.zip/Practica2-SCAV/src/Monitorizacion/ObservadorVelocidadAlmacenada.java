/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import javax.swing.JButton;
import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorVelocidadAlmacenada implements I_Observador{

    private Observable observable;
    private JTextField visorVelocidadAlmacenada;
    
    
    
    public ObservadorVelocidadAlmacenada(Observable observable, JTextField visorVelocidadAlmacenada){
	this.observable = observable;
	this.visorVelocidadAlmacenada = visorVelocidadAlmacenada;
        this.observable.addObservador(this);
        
    }
    
    @Override
    public void update() {
        int velocidadAlmacenada = (int)this.observable.getVehiculo().getControl().getVelocidadAutomatica();
        visorVelocidadAlmacenada.setText(String.valueOf(velocidadAlmacenada));
    }
    
}
