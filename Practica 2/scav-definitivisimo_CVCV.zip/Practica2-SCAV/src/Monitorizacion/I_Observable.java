/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

/**
 *
 * @author ancaor
 */
public interface I_Observable {
    public void addObservador(I_Observador observador);
    public void removeObservador(I_Observador observador);
}
