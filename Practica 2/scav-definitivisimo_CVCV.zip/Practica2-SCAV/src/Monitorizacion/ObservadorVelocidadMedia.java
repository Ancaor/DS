/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import javax.swing.JButton;
import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorVelocidadMedia implements I_Observador{

    private Observable observable;
    private JTextField visorVelocidadMedia;
    
    
    
    public ObservadorVelocidadMedia(Observable observable, JTextField visorVelocidadMedia){
	this.observable = observable;
	this.visorVelocidadMedia = visorVelocidadMedia;
        this.observable.addObservador(this);
        
    }
    
    @Override
    public void update() {
        int velocidadMedia = (int)this.observable.getVehiculo().getVelocidadMedia();
        visorVelocidadMedia.setText(String.valueOf(velocidadMedia));
    }
    
}
