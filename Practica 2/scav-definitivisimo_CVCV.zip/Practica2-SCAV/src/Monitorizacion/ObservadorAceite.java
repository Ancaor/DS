/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import Controles.TipoNivel;
import javax.swing.JProgressBar;

/**
 *
 * @author ancaor
 */
public class ObservadorAceite implements I_Observador{

    private Observable observable;
    private JProgressBar medidor;
    
    
    public ObservadorAceite(Observable observable, JProgressBar medidor){
	this.observable = observable;
	this.medidor = medidor;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int kilometro_cambio = observable.getVehiculo().getNivel(TipoNivel.ACEITE).getKmActual();
        int kilometros_cambio =  (int)observable.getVehiculo().getDistanciaRecorrida() - kilometro_cambio;
        //System.out.println("kilometros deposito:" + kilometros_deposito);
        int kilometros_maximos = observable.getVehiculo().getNivel(TipoNivel.ACEITE).getKmMax();
     //   System.out.println("kilometros max:" + kilometros_maximos);
        double porcentaje = (kilometros_cambio * 100)/kilometros_maximos;
       // System.out.println(porcentaje);
        int aux = 100 - (int)porcentaje;
       // System.out.println(aux + "%");
        medidor.setValue((int) aux);
        
    }
    
}
