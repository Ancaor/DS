package Controles;

/**
 *
 * @author ancaor
 */
public class Nivel_Aceite extends Nivel{
    private final int kmMax =  20000;
    /**
     *
     */
    public Nivel_Aceite(){
        super(TipoNivel.ACEITE);
    }
    
    @Override
    public int getKmMax() {
        return kmMax;
    }
    
}
