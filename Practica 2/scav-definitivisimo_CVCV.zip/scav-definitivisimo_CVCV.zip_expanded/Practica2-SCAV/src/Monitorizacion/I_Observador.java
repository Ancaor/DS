package Monitorizacion;

/**
 *
 * @author ancaor
 */
public interface I_Observador {
    
    
    public void update();
}
