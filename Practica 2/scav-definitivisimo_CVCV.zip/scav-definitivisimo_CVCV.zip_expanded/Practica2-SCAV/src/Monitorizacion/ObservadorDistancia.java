/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitorizacion;

import javax.swing.JTextField;

/**
 *
 * @author ancaor
 */
public class ObservadorDistancia implements I_Observador{

    private Observable observable;
    private JTextField cuentakilometros;
    
    
    public ObservadorDistancia(Observable observable, JTextField cuentakilometros){
	this.observable = observable;
	this.cuentakilometros = cuentakilometros;
        this.observable.addObservador(this);
    }
    
    @Override
    public void update() {
        int distancia = (int)this.observable.getVehiculo().getDistanciaRecorrida();
        cuentakilometros.setText(String.valueOf(distancia));
    }
    
}
