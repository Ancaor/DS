package Monitorizacion;

/**
 *
 * @author ancaor
 */
public interface I_Observable {
    public void addObservador(I_Observador observador);
    public void removeObservador(I_Observador observador);
}
