package Vehiculo;

import Controles.*;
import Controles.Nivel;
import Controles.TipoNivel;
import java.util.ArrayList;
import Controles.FactoriaNivel;


public class Vehiculo extends Thread{
    
    
    private static Vehiculo vehiculo;	
    
    private double tiempoInicio;
    private double tiempoActual;
    
    private double factorAceleracion;
    private double velocidad;
    private int estadoMotor;
    private double frenado;
    private double distanciaRecorrida;
    private double rozAire;		
    private double rozSuelo;		
    private boolean motorApagado;				
    private double velocidadMedia;
    
    private Control control;
    private Acelerador acelerador;
    private CalculadorVelocidad calculadorVelocidad;
    private Palanca palanca;
    private Freno freno;

    
    
    private Nivel combustible2 = FactoriaNivel.crearNivel(TipoNivel.COMBUSTIBLE);
    private Nivel aceite = FactoriaNivel.crearNivel(TipoNivel.ACEITE);
    private Nivel general = FactoriaNivel.crearNivel(TipoNivel.GENERAL);
    private Nivel frenos = FactoriaNivel.crearNivel(TipoNivel.FRENOS);
    
    private ArrayList<Nivel> niveles = new ArrayList<>();

    
    
    
    private Vehiculo( ) {

        this.tiempoActual = 0;
        this.tiempoInicio=0;
        this.velocidad = 0.0;
        this.factorAceleracion = 0.0;
        this.estadoMotor = 0;
        this.frenado = 0.0;
        this.distanciaRecorrida = 0.0;
        this.rozAire = 0.005;
        this.rozSuelo = 0.05;		
        this.motorApagado = false;
        this.acelerador = new Acelerador(this);
        this.calculadorVelocidad = new CalculadorVelocidad(this);
        this.control = new Control(this.acelerador, this.calculadorVelocidad);
        this.palanca = new Palanca(this.control);
        this.freno = new Freno(this, this.control);
        this.velocidadMedia = 0;
        
        niveles.add(combustible2);
        niveles.add(frenos);
        niveles.add(aceite);
        niveles.add(general);
    }
    

    public double getDistanciaRecorrida() {
        return this.distanciaRecorrida;
    }

    public double getVelocidad() {
        return this.velocidad;
    }

    public int getEstadoMotor() {
        return this.estadoMotor;
    }
    
    public double getfactorAceleracion() {
        return this.factorAceleracion;
    }
    
    public double getVelocidadMedia() {
        return velocidadMedia;
    }

    public Control getControl() {
        return control;
    }

    public Acelerador getAcelerador() {
        return acelerador;
    }

    public CalculadorVelocidad getCalculadorVelocidad() {
        return calculadorVelocidad;
    }

    public Palanca getPalanca() {
        return palanca;
    }

    public Freno getFreno() {
        return freno;
    }
    
    public Nivel getNivel(TipoNivel t){
        for(Nivel n : niveles){
            if(n.getTipo() == t)
                return n;
        }
        return null;
    }
    
    public static Vehiculo getVehiculo(){
        if(vehiculo == null){
            vehiculo = new Vehiculo();
        }
        return vehiculo;
    }
    
    public void rellenarNivel(TipoNivel t){
        for(Nivel n : niveles){
            if(n.getTipo()== t){
                n.setKilometro(this.distanciaRecorrida);
            }
        }
    }
    
    public void frenar(int CteFRENADO) {		
        this.frenado = CteFRENADO;				
    }
    
    public void soltarFreno() {
        this.frenado = 0.0;
    }
    
    public void aumentarFactorAceleracion(double CteACELERACION) {
        if (this.factorAceleracion < 1) {
            this.factorAceleracion += CteACELERACION;
        }
        if (this.factorAceleracion > 1) {
            this.factorAceleracion = 1;
        }
    }

    public void disminuirFactorAceleracion(double CteACELERACION) {
        if (this.factorAceleracion > 0.0) {
            this.factorAceleracion -= CteACELERACION;
        }
        if (this.factorAceleracion < 0.0) {
            this.factorAceleracion = 0.0;
        }
    }
    
    public void resetFactorAceleracion() {
        this.factorAceleracion = 0.0;
    }
     
    
    public void arrancar() {
        this.estadoMotor = 1;
        this.motorApagado = false;
        if (!this.isAlive()) {
            this.start();
            this.tiempoInicio = System.currentTimeMillis();
        }
    }
    
    public void pararMotor() {
        this.estadoMotor = 0;
    }

    public void salir() {
        this.estadoMotor = 0;
        this.motorApagado = true;
    }
    
    @Override
    public void run() {
        double tiempoDistanciaInicio=0;
        double tiempoDistanciaFin=0;
        while (!this.motorApagado) {
            try {
                
                tiempoDistanciaInicio = System.currentTimeMillis();
                
                this.tiempoActual = System.currentTimeMillis();
                double difTiempo = ((this.tiempoActual - this.tiempoInicio)/360000);
                this.velocidad += this.factorAceleracion - this.frenado - this.rozSuelo - this.rozAire * this.velocidad;
                if (this.velocidad < 0.0) {
                    this.velocidad = 0.0;
                }
                this.distanciaRecorrida += this.velocidad * ((tiempoDistanciaInicio - tiempoDistanciaFin)/360000);// -5 en un inicio
                
                
                this.velocidadMedia = this.distanciaRecorrida / difTiempo;
                tiempoDistanciaFin = tiempoDistanciaInicio;
                Vehiculo.sleep(100);
            }
            catch (InterruptedException interruptedException) {
            }
        }
    }
        
}
