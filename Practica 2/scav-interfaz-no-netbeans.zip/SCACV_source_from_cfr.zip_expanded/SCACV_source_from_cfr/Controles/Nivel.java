/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controles;

/**
 *
 * @author ancaor
 */
public abstract class Nivel {
    
    private TipoNivel tipo;
    private int km_actual;
    
    public Nivel(TipoNivel tipo){
        km_actual = 0;
        this.tipo = tipo;
    }
    
    public abstract int getKmMax();
    
    public int getKmActual(){
        return km_actual;
    }
    
}
